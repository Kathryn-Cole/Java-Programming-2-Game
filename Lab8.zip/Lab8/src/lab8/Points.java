
package lab8;


public class Points {
    private int count;
    
    public Points(){
        this.count = 0;
    }
    public Points(int c){
        this.count = c;
    }
    public int getPoints(){
        return this.count;
    }
    public void setPoints(int newCount){
        this.count = newCount;
    }
}
