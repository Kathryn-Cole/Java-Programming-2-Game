/*
 * Kathryn Cole
 * 04/26/2020
 * Lab8
 * "Point 'n Click" game
 */
package lab8;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Game extends Application {
    
//global variables that go into multiple methods
    Integer seconds;                        //holds time for timer
    Button bad = new Button();              //button that holds the points that take away hearts
    Button point = new Button();            //button that holds the points that add to your score
    Button finishGame = new Button();       //button that finishes the game
    Pane group = new Pane();                //pane that holds the main game board
    GridPane lifeSetUp = new GridPane();    //gridpane that holds the hearts (life bar)
    GameOver gameOver = new GameOver();     //object that holds the boolean to determine if the criteria for ending a game is present
    BorderPane game = new BorderPane();     //holds the game board and the scoreboard
    Label labelTime = new Label();          //label for the timer
    Label labelScore = new Label();         //label that holds the score
    Hearts lives = new Hearts();            //holds the amount of hearts the user has in the game
    Points count = new Points();            //holds the amount of points the user got
    int points = 0;                         //holds the number for the Points Object so we can manipulate the number and make comparisons
    int hearts = 0;                         //holds the number for the Hearts Object so we can make comparisons
    Rectangle filler1 = new Rectangle();    //filler to make the layout nicer
    Rectangle filler2 = new Rectangle();
    final int max = 799;                    //the max multiplier for the random number generators
    ImageView lose = new ImageView(new Image("img/lose.png")); //holds the image that tells you that you lose
    ImageView winner = new ImageView(new Image("img/win.png"));//holds the image that tells you that you won
    boolean win = false;                    //determines if you won
    boolean lost = false;                   //determines if you lost

    @Override
    public void start(Stage primaryStage) {
        //settings for some of the global variables
        labelTime.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 20));
        labelTime.setTextFill(Color.ORANGERED);
        labelScore.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 20));
        labelScore.setTextFill(Color.ORANGERED);
        filler1.setWidth(50);
        filler2.setWidth(50);
        group.setPrefSize(900, 900);
        
        //setting up panes for our scenes
        BorderPane mainMenu = new BorderPane();
        BorderPane instruct = new BorderPane();
        BorderPane play = new BorderPane();
        play.prefHeight(1000);
        play.prefWidth(1000);
        BorderPane results = new BorderPane();
        BorderPane ready = new BorderPane();

        //setting up the buttons and their graphics
        Button again1 = new Button();
        again1.setGraphic(new ImageView(new Image("img/again.png")));
        again1.setStyle("-fx-background-color: transparent");
        Button again2 = new Button();
        again2.setGraphic(new ImageView(new Image("img/again.png")));
        again2.setStyle("-fx-background-color: transparent");
        Button back = new Button();
        back.setGraphic(new ImageView(new Image("img/back.png")));
        back.setStyle("-fx-background-color: transparent");
        Button back1 = new Button();
        back1.setGraphic(new ImageView(new Image("img/back.png")));
        back1.setStyle("-fx-background-color: transparent");
        Button back2 = new Button();
        back2.setGraphic(new ImageView(new Image("img/back.png")));
        back2.setStyle("-fx-background-color: transparent");
        Button easy = new Button();
        easy.setGraphic(new ImageView(new Image("img/easy.png")));
        easy.setStyle("-fx-background-color: transparent");
        Button hard = new Button();
        hard.setStyle("-fx-background-color: transparent");
        hard.setGraphic(new ImageView(new Image("img/hard.png")));
        Button inst = new Button();
        inst.setGraphic(new ImageView(new Image("img/instructions.png")));
        inst.setStyle("-fx-background-color: transparent");
        Button medium = new Button();
        medium.setGraphic(new ImageView(new Image("img/medium.png")));
        medium.setStyle("-fx-background-color: transparent");
        Button start = new Button();
        start.setGraphic(new ImageView(new Image("img/play.png")));
        start.setStyle("-fx-background-color: transparent");
        Button start1 = new Button();
        start1.setGraphic(new ImageView(new Image("img/startgame.png")));
        start1.setStyle("-fx-background-color: transparent");
        //setting up graphics for global buttons
        bad.setGraphic(new ImageView(new Image("img/bad.png")));
        bad.setStyle("-fx-background-color: transparent");
        point.setGraphic(new ImageView(new Image("img/point.png")));
        point.setStyle("-fx-background-color: transparent");
        finishGame.setGraphic(new ImageView(new Image("img/time.png")));
        finishGame.setStyle("-fx-background-color: transparent");
        
        //setting up the hearts image
        ImageView heart = new ImageView();
        heart.setImage(new Image("img/heart.png"));
        //setting up the title graphics
        ImageView mainTitle = new ImageView(new Image("img/title.png"));
        mainTitle.setFitHeight(250);
        mainTitle.setFitWidth(900);
        ImageView title = new ImageView(new Image("img/title.png"));
        title.setFitHeight(100);
        title.setFitWidth(400);
        ImageView title1 = new ImageView(new Image("img/title.png"));
        title1.setFitHeight(100);
        title1.setFitWidth(400);
        
        //setting up the background
        BackgroundImage backgroundimage = new BackgroundImage(new Image("img/background.png"),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        Background background = new Background(backgroundimage);
        
        //putting the main title screen together
        mainMenu.setTop(mainTitle);
        mainMenu.setAlignment(mainTitle, Pos.CENTER);
        mainMenu.setCenter(start);
        mainMenu.setBottom(inst);
        mainMenu.setBackground(background);

        //the game instructions
        Text direct = new Text("Click the blue circles to collect points before time runs out!\n\n"
                + "Don't click on the pentagons, or you'll lose hearts.\n\n"
                + "If you run out of hearts or don't get any points, you lose the game.\n\n"
                + "After you select a difficulty, hit the ''Start Game'' button when you are ready to start\n\n"
                + "Note: When you press ''Start Game'' the game will start immediately, \nso only "
                + "press it when you are ready");
        direct.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 20));
        //setting up the instructions title graphic
        ImageView instr = new ImageView("img/instructions.png");
        //setting up instructions page
        instruct.setTop(instr);
        instruct.setAlignment(instr, Pos.CENTER);
        instruct.setCenter(direct);
        instruct.setBottom(back);
        
        //more filler
        Rectangle filler = new Rectangle();
        filler.setFill(Color.TRANSPARENT);
        filler.setWidth(300);
        filler.setHeight(250);
        
        //pane that holds the buttons for easy, medium, and hard mode
        GridPane difficultySettings = new GridPane();
        difficultySettings.setPadding(new Insets(1, 1, 100, 1));
        difficultySettings.add(filler, 0, 0);
        difficultySettings.add(easy, 1, 1);
        difficultySettings.add(medium, 1, 2);
        difficultySettings.add(hard, 1, 3);
        
        //difficulty setting page
        play.setTop(title);
        play.setAlignment(title, Pos.CENTER);
        play.setCenter(difficultySettings);
        play.setAlignment(difficultySettings, Pos.CENTER);
        play.setBottom(back1);
        play.setBackground(background);
        
        //a ready page so you can start when you want to
        ready.setTop(title1);
        ready.setAlignment(title1, Pos.CENTER);
        ready.setCenter(start1);
        ready.setBackground(background);
        ready.setBottom(back2);
        
        //setting up the displays foor the game board
        //score board
        Text score = new Text("Score: ");
        score.setFill(Color.ORANGERED);
        score.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 20));
        Text time1 = new Text("Time: ");
        time1.setFill(Color.ORANGERED);
        time1.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 20));
        
        //fills the timer to make the scoreboard more neat
        Rectangle timerBox = new Rectangle();
        timerBox.setFill(Color.TRANSPARENT);
        timerBox.setWidth(100);
        
        //fills the score to make the score more neat
        Rectangle scoreBox = new Rectangle();
        scoreBox.setFill(Color.TRANSPARENT);
        scoreBox.setWidth(75);
        
        //fills the life bar to make the life more neat
        Rectangle lifeBox = new Rectangle();
        lifeBox.setFill(Color.TRANSPARENT);
        lifeBox.setWidth(50);
        
        //setting up the timer graphic
        HBox clockSetUp = new HBox(2);
        HBox.setMargin(time1, new Insets(1, 1, 1, 1));
        HBox.setMargin(labelTime, new Insets(1, 1, 1, 5));
        clockSetUp.getChildren().addAll(time1, labelTime);
        //set it in it's own gridpane to keep it all together
        GridPane clock = new GridPane();
        clock.add(timerBox, 0, 0);
        clock.add(clockSetUp, 0, 0);
        //setting up scoreboard graphic
        HBox scoreSetUp = new HBox(2);
        HBox.setMargin(score, new Insets(1, 1, 1, 1));
        HBox.setMargin(labelScore, new Insets(1, 1, 1, 5));
        scoreSetUp.getChildren().addAll(score, labelScore);
        //give it it's own gridpane to keep it together
        GridPane scoreView = new GridPane();
        scoreView.add(scoreBox, 0, 0);
        scoreView.add(scoreSetUp, 0, 0);
        //life has it's own gridpane to add the graphics to
        GridPane lifeView = new GridPane();
        lifeView.add(lifeBox, 0, 0);
        lifeView.add(lifeSetUp, 0, 0);

        //putting the whole scoreboard together
        HBox scoreBoard = new HBox(6);
        HBox.setMargin(clock, new Insets(1, 1, 1, 1));
        HBox.setMargin(scoreView, new Insets(1, 500, 1, 1));
        HBox.setMargin(lifeView, new Insets(1, 1, 1, 1));
        scoreBoard.getChildren().addAll(clock, scoreView, lifeView);

        //setting up the game board
        game.setTop(scoreBoard);
        game.setCenter(group);
        game.setAlignment(group, Pos.CENTER);
        game.getCenter().setStyle("-fx-background-color: white");
        game.setBackground(background);
        game.setLeft(filler1);
        game.setRight(filler2);

        //(partially)setting up results screen
        results.setBottom(again1);
        results.setBackground(background);
        
        //putting the panes into scenes
        Scene gameMenu = new Scene(mainMenu, 1000, 1000);
        Scene directions = new Scene(instruct, 1000, 1000);
        Scene difficulty = new Scene(play, 1000, 1000);
        Scene getReady = new Scene(ready, 1000, 1000);
        Scene gameStage = new Scene(game, 1000, 1000);
        Scene finalResults = new Scene(results, 1000, 1000);
        
        //telling the buttons what to do
        //takes you to the game instructions
        inst.setOnAction(e -> {
            primaryStage.setScene(directions);
        });
        //takes you back to the title screen from the main menu
        back.setOnAction(e -> {
            primaryStage.setScene(gameMenu);
        });
        //takes you back to the title screen from the difficulty setting screen
        back1.setOnAction(e -> {
            primaryStage.setScene(gameMenu);
        });
        //takes you back to the difficulty settings from the ready screen
        back2.setOnAction(e -> {
            primaryStage.setScene(difficulty);
        });
        //takes you to the difficulty setting from the title screen
        start.setOnAction(e -> {
            primaryStage.setScene(difficulty);
        });
        //sets the game to easy mode and takes you to the ready screen
        easy.setOnAction(e -> {
            setDifficultyEasy();
            primaryStage.setScene(getReady);
        });
        //sets the game to medium mode and takes you to the ready screen
        medium.setOnAction(e -> {
            setDifficultyMedium();
            primaryStage.setScene(getReady);
        });
        //sets the game to hard mode and takes you to the ready screen
        hard.setOnAction(e -> {
            setDifficultyHard();
            primaryStage.setScene(getReady);
        });
        //starts the game from the ready screen
        start1.setOnAction(e -> {
            primaryStage.setScene(gameStage);
            //puts the hearts on the board
            displayHearts();
            //starts the game
            gameStart();

        });
        //lets you play again after the game
        again1.setOnAction(e -> {
            //resets all the variables that don't get set when you pick a difficulty
            game.setCenter(group);
            group.getChildren().clear();
            count.setPoints(0);
            hearts = 0;
            points = 0;
            //takes you to the difficulty menu
            primaryStage.setScene(difficulty);
        });
        //at the end of the game,  this button takes you to your result
        finishGame.setOnAction(e -> {
            primaryStage.setScene(finalResults);
            //set up result pane
            GridPane resultsPane = new GridPane();
            //decides which graphic to deplay depending on whenther you won or lost
            if (win == true && lost == false) {
                results.setTop(winner);
                results.setAlignment(winner, Pos.CENTER);
            } else if (win == false && lost == true) {
                results.setTop(lose);
                results.setAlignment(lose, Pos.CENTER);
            }
            //moe filler!
            Rectangle filler3 = new Rectangle();
            filler3.setWidth(300);
            filler3.setHeight(450);
            filler3.setFill(Color.TRANSPARENT);
            //displays final score
            Text finalScore = new Text("" + points);
            finalScore.setFill(Color.ORANGERED);
            finalScore.setFont(new Font("Arial Black", 75));
            //labels score as your score
            Text resultsScore = new Text("Score: ");
            resultsScore.setFill(Color.ORANGERED);
            resultsScore.setFont(new Font("Arial Black", 75));
            //putting the results pant together
            resultsPane.setPadding(new Insets(5, 5, 5, 5));
            resultsPane.add(filler3, 1, 0);
            resultsPane.add(resultsScore, 2, 0);
            resultsPane.add(finalScore, 3, 0);
            resultsPane.setHalignment(finalScore, HPos.RIGHT);
            //final view
            results.setCenter(resultsPane);
        });
        //gives you points when you press it
        point.setOnAction(e -> {
            goodPoint();
            points = count.getPoints();
        });
        //takes hearts when you prress it
        bad.setOnAction(e -> {
            badPoint();
        });
        
        //setting up stage
        primaryStage.setScene(gameMenu);
        primaryStage.setHeight(1000);
        primaryStage.setWidth(1000);
        primaryStage.setResizable(false);
        primaryStage.show();

    }
    //the timer
    private void timerStart() {
        Timeline time = new Timeline();
        time.setCycleCount(Timeline.INDEFINITE);
        //if for whatever reason time is null, it stops
        if (time == null) {
            time.stop();
        }
        //setting up actions for the frames every second
        KeyFrame frame = new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            //every second...
            @Override
            public void handle(ActionEvent event) {
                //clock counts down one second
                seconds--;
                //updates the label to show the current time
                labelTime.setText(seconds.toString());
                //adds a new point to the board
                addPoint();
                //updates your points
                labelScore.setText("" + points);
                //makes a decidions about whether the end game criteria has been met
                decision();
                //if time runs out or end game criteria has been met it stops the timer
                if (seconds <= 0 || gameOver.getGameOver() != false) {
                    time.stop();
                }
            }
        });
        time.getKeyFrames().add(frame);
        time.playFromStart();
    }
    //method for starting the game
    public void gameStart() {
        //sets gameover to false because it's the beginning of the game
        gameOver.setGameOver(false);
        //starts the timer
        timerStart();

    }
    //method that adds points to the board
    public void addPoint() {
        //there is a possibility for a illegalargumentexception, to i added a try/catch
        try {
            //adds 1 good point and 1 bad point
            addGoodPoint();
            addBadPoint();
        //if the exception has to be caught, it clears the board and starts over
        } catch (IllegalArgumentException e) {
            group.getChildren().clear();
            addPoint();
        }

    }
    //method for addint a good point
    public void addGoodPoint() {
        //as long as the game isn't over
        if (gameOver.getGameOver() != true) {
            //selects a random location for the point
            int x = (int) (Math.random() * max) + 1;
            int y = (int) (Math.random() * max) + 1;
            //adds point to the board
            point.relocate(x, y);
            group.getChildren().add(point);
        }
    }
    //method for adding bad point
    public void addBadPoint() {
        //as long a the game isn't over
        if (gameOver.getGameOver() != true) {
            //selects a random place on the board
            int x = (int) (Math.random() * max) + 1;
            int y = (int) (Math.random() * max) + 1;
            //adds point to board
            bad.relocate(x, y);
            group.getChildren().add(bad);
        }
    }
//difficulty settings methods
    //easy sets the hearts to 3 and the time to 30 seconds (the additional second is at the beginning to allow the user to prepare)
    public void setDifficultyEasy() {
        lives.setHearts(3);
        seconds = 31;
    }
    //medium sets the hearts to 2 and the time to 20 seconds (the additional second is at the beginning to allow the user to prepare)
    public void setDifficultyMedium() {
        lives.setHearts(2);
        seconds = 21;
    }
    //hard sets the hearts to 1 and the time to 10 seconds (the additional second is at the beginning to allow the user to prepare)
    //very handy for testing
    public void setDifficultyHard() {
        lives.setHearts(1);
        seconds = 11;
    }
    //method for when you click a good point
    public void goodPoint() {
        //score counter goes up
        count.setPoints(count.getPoints() + 1);
        //board is cleared
        group.getChildren().clear();
    }
    //method for when you click a bad point
    public void badPoint() {
        //hearts goes down
        lives.setHearts(lives.getHearts() - 1);
        //board is cleared
        group.getChildren().clear();
        //the heart graphics regenerate
        displayHearts();
    }
    //end of game decision method
    public void decision() {
        //if you have lives left or if the time runs out
        if (lives.getHearts() <= 0 || seconds <= 0) {
            //gameover is set to true to let the other methods know they need to stop
            gameOver.setGameOver(true);
            //clears the board so you can't click anymore points
            group.getChildren().clear();
            //activates game endng protocol
            gameFinish();
        }
    }
    //game ending protocol
    public void gameFinish() {
        //removes the game board
        game.getChildren().remove(group);
        //adds the endgame button to take you to the results
        game.setCenter(finishGame);
        game.setAlignment(finishGame, Pos.CENTER);
        //adds your points to a local global variable so they can be displayed/compared
        points = count.getPoints();
        //adds hearts to a local global variable so they can be compared
        hearts = lives.getHearts();
        //if you have no hearts and no points, it sets lost to true, and win to false
        if (hearts <= 0 || points <= 0) {
            lost = true;
            win = false;
        } 
        //otherwise, you win, and it does the opposite
        else {
            lost = false;
            win = true;
        }

    }
    //method that generates the heart graphics on the scoreboard
    public void displayHearts() {
        //first it clears all the hearts so it has a fresh canvas and doesn't throw any exceptions
        lifeSetUp.getChildren().clear();
        //it finds out how many lives you have and makes sure it only loops that many times
        for (int i = 0; i < lives.getHearts(); i++) {
            //sets up graphic
            Pane img = new HBox();
            img.setPadding(new Insets(1, 1, 1, 1));
            Image pic = new Image("img/heart.png");
            ImageView view = new ImageView(pic);
            img.getChildren().add(view);
            //adds to the scoreboard depending on what place it needs to go in
            lifeSetUp.add(img, i, 0);
        }
    }
    //launches the game
    public static void main(String[] args) {
        launch(args);
    }
}
//if you read down this far, you deserve a cookie, because that's a lot of reading