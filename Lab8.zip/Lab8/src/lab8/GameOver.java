
package lab8;

public class GameOver {
    private boolean endGame;
    
    public GameOver(){
        this.endGame = false;
    }
    public GameOver(boolean g){
        this.endGame = g;
    }
    public boolean getGameOver(){
        return this.endGame;
    }
    public void setGameOver(boolean newGameOver){
        this.endGame = newGameOver;
    }
}
