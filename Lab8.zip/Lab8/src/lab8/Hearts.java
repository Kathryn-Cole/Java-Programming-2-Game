
package lab8;


public class Hearts {
    private int hearts;
    
    public Hearts(){
        this.hearts = 0;
    }
    public Hearts(int h){
        this.hearts = h;
    }
    public int getHearts(){
        return this.hearts;
    }
    public void setHearts(int newHearts){
        this.hearts = newHearts;
    }
}
